#!/bin/sh
# rtkrcv shutdown script

echo shutdown script ok

